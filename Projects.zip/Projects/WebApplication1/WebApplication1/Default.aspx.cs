﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
using System.IO;
using System.Collections;

namespace WebApplication1
{
    public partial class _Default : System.Web.UI.Page
    {

        Robot userRobot = new Robot();
        Robot r1, r2;

        protected void Page_Load(object sender, EventArgs e)
        {
            Robot1_Data.InnerHtml = "<h2>Upload din robot...</h2>";
            Robot2_Data.InnerHtml = "<h2>Vælg din modstander...</h2>";

        }

        protected void Page_PreRender(object sender, EventArgs e)
        {
            if (Session["user_robot"] != null)
            {
                userRobot = (Robot)Session["user_robot"];
                HiddenRobot1Id.Value = Convert.ToString(userRobot.getId());
                Robot1_Data.InnerHtml = "<h2>" + userRobot.getNavn() + "</h2>";
            }
            
            genRightNav();

        }

        private void genRightNav() {
            if (Session["user_robot"] != null)
                userRobot = (Robot)Session["user_robot"];
            ArrayList robots = new RobotDBO().getAllRobots();
            RobotsList.InnerHtml = "";
            foreach (Robot r in robots)
            {
                string cssClass = "";
                if (userRobot.getId() == r.getId()) cssClass = " user-robot";
                RobotsList.InnerHtml += "<li id=\"" + r.getId() + "\" class=\"btn-group" + cssClass + "\"><a data-robotid=\"" + r.getId() + "\" data-robotname=\"" + r.getNavn() + "\" class=\"btn\">" + r.getNavn() + "</a><a href=\"xmls/" + r.getUniqueFileUrl() + "\" class=\"btn btn-primary\">Download</a></li>";
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (FileUpload1.HasFile)
            {

                //Directory.CreateDirectory("\\temp\\uploads\\");
                string uploadPath = "\\Users\\Administrator.WIN-DBHSPC6ODT5\\Documents\\Visual Studio 2010\\Projects\\WebApplication1\\WebApplication1\\xmls\\";
                
                FileUpload1.SaveAs(uploadPath + FileUpload1.FileName);

                r1 = new Robot();

                r1.loadRobotXML(FileUpload1.FileName, uploadPath);

                Session["user_robot"] = r1;
            }

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            int r1_id = Convert.ToInt32(HiddenRobot1Id.Value);
            int r2_id = Convert.ToInt32(HiddenRobot2Id.Value);
            if (r1_id > 0 && r2_id > 0)
            {
                r1 = new RobotDBO().getRobot(r1_id);
                r2 = new RobotDBO().getRobot(r2_id);
                int rounds = 10;
                RobotGame game = new RobotGame(r1,r2,rounds);

                int result = game.fight();

                switch (result) {
                    case 1: StatusDiv.InnerHtml = r1.getNavn() + " vandt over " + r2.getNavn() + "!!"; break;
                    case 2: StatusDiv.InnerHtml = r2.getNavn() + " vandt over " + r1.getNavn() + "!!"; break;
                    default: StatusDiv.InnerHtml = "Kampen endte uafgjort!"; break;
                }
                StatusDiv.InnerHtml += "<script>$(document).ready(function() {displayGameFlow('" + r1.getJSONData() + "','" + r2.getJSONData() + "'," + rounds + ")});</script>";
            }
        }


    }
}
