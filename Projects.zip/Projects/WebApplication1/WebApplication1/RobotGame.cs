﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1
{
    
    
    public class RobotGame
    {
        private Robot r1;
        private Robot r2;
        private int rounds;

        public RobotGame(Robot _r1, Robot _r2, int _rounds) {
            r1 = _r1;
            r2 = _r2;
            rounds = _rounds;
        }

        public int fight() {
            for (int i = 0; i < rounds; i++ )
            {
                if (r1.getVaaben(i) != r2.getSkjold(i)) {
                    r2.dieOnce();
                }
                if (r2.getVaaben(i) != r1.getSkjold(i))
                {
                    r1.dieOnce();
                }
                if (r1.getLiv() < 0 && r2.getLiv() < 0) {
                    r1.newUafgjort();
                    r2.newUafgjort();
                    save();
                    return 0;
                }
                if (r1.getLiv() < 0) {
                    r2.newWin();
                    r1.newLoose();
                    save();
                    return 2;
                }
                if (r2.getLiv() < 0)
                {
                    r1.newWin();
                    r2.newLoose();
                    save();
                    return 1;
                }
            }
            r1.newUafgjort();
            r2.newUafgjort();
            save();
            return 0;
        }

        private void save()
        {
            r1.saveRobot2DB();
            r2.saveRobot2DB();
            r1.saveRobot2XML();
            r2.saveRobot2XML();
        }
    }
}