﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml.Schema;
using System.Xml;
using System.Collections;
using System.IO;

namespace WebApplication1
{
    
    public class Robot
    {
        private int id = -1;
        private string navn;
        private ArrayList skjold;
        private ArrayList vaaben;
        private int liv;
        private int initLiv = 5;
        private int sejre;
        private int tab;
        private int uafgjort;

        public int Id {get {return id;} set {id = Id;}}
        public string Navn {get {return navn;} set {navn = Navn;}}
        public int Liv {get {return liv;} set {liv = Liv;}}
        public int InitLiv {get {return initLiv;} set {initLiv = InitLiv;}}
        public int Sejre {get {return sejre;} set {sejre = Sejre;}}
        public int Tab {get {return tab;} set {tab = Tab;}}
        public int Uafgjort {get {return uafgjort;} set {uafgjort = Uafgjort;}}

        private string xmlFileName;
        private string xmlUploadPath;
        XmlDocument xmlDocument;


        public Robot() {
            skjold = new ArrayList();
            vaaben = new ArrayList();
            xmlDocument = new XmlDocument();
        }

        public Robot(int _id, string _navn, int _liv, int _tab, int _sejre, int _uafgjort, string _filename, ArrayList _skjold, ArrayList _vaaben)
        {
            xmlFileName = _filename;
            navn = _navn;
            id = _id;
            liv = _liv;
            tab = _tab;
            sejre = _sejre;
            uafgjort = _uafgjort;
            skjold = _skjold;
            vaaben = _vaaben;
            xmlDocument = new XmlDocument();
            xmlUploadPath = "\\Users\\Administrator.WIN-DBHSPC6ODT5\\Documents\\Visual Studio 2010\\Projects\\WebApplication1\\WebApplication1\\xmls\\";
        }

        public bool loadRobotXML(string xmlFile, string uploadPath)
        {
            xmlFileName = xmlFile;
            xmlUploadPath = uploadPath;
            readXMLFileAndFillVars(uploadPath + xmlFile);
            saveRobot2DB();
            saveRobot2XML();
            return true;
        }

        public bool saveRobot2XML() {
            writeToXMLFile(xmlUploadPath + getUniqueFileUrl());
            return true;
        }

        public bool saveRobot2DB()
        {
            id = new RobotDBO().saveRobot(this);
            return true;
        }

        public string getNavn() {
            return navn;
        }

        public int getLiv()
        {
            return liv;
        }

        public int getSejre()
        {
            return sejre;
        }

        public int getTab()
        {
            return tab;
        }

        public int getUafgjort()
        {
            return uafgjort;
        }

        public int getVaaben(int runde)
        {
            if (runde >= vaaben.Count && runde != 0)
                runde = runde % vaaben.Count;
            return Convert.ToInt32(vaaben[runde]);
        }

        public int getSkjold(int runde)
        {
            if (runde >= skjold.Count && runde != 0)
                runde = runde % skjold.Count;
            return Convert.ToInt32(skjold[runde]);
        }

        public ArrayList getVaaben()
        { return vaaben; }

        public ArrayList getSkjold()
        { return skjold; }

        private void readXMLFileAndFillVars(string path)
        {
            xmlDocument.Load(path);
            XmlNodeList rounds = xmlDocument.GetElementsByTagName("runde");
            for (int i = 0; i < rounds.Count; i++) {
                XmlNode n = rounds.Item(i);
                for (int j = 0; j < n.Attributes.Count; j++)
                {
                    XmlNode a = n.Attributes.Item(j);
                    if (a.Name == "vaaben") vaaben.Add(Convert.ToInt32(a.Value));
                    if (a.Name == "skjold") skjold.Add(Convert.ToInt32(a.Value));
                }
            }
            if (xmlDocument.GetElementsByTagName("id").Count > 0)
                id = Convert.ToInt32(xmlDocument.GetElementsByTagName("id").Item(0).InnerText);
            navn = Convert.ToString(xmlDocument.GetElementsByTagName("navn").Item(0).InnerText);
            liv = Convert.ToInt32(xmlDocument.GetElementsByTagName("liv").Item(0).InnerText);
            uafgjort = Convert.ToInt32(xmlDocument.GetElementsByTagName("uafgjort").Item(0).InnerText);
            tab = Convert.ToInt32(xmlDocument.GetElementsByTagName("tab").Item(0).InnerText);
            sejre = Convert.ToInt32(xmlDocument.GetElementsByTagName("sejre").Item(0).InnerText);
        }

        private void writeToXMLFile(string p)
        {
            xmlDocument.Load(xmlUploadPath + xmlFileName);
            if (xmlDocument.GetElementsByTagName("id").Count > 0)
                xmlDocument.GetElementsByTagName("id").Item(0).InnerText = Convert.ToString(id);
            xmlDocument.GetElementsByTagName("uafgjort").Item(0).InnerText = Convert.ToString(uafgjort);
            xmlDocument.GetElementsByTagName("sejre").Item(0).InnerText = Convert.ToString(sejre);
            xmlDocument.GetElementsByTagName("tab").Item(0).InnerText = Convert.ToString(tab);
            xmlDocument.GetElementsByTagName("liv").Item(0).InnerText = Convert.ToString(initLiv);
            
            xmlDocument.Save(p);
        }

       
        public void dieOnce()
        {
            liv--;
        }

        public void newWin()
        {
            sejre++;
        }

        public void newLoose()
        {
            tab++;
        }

        public void newUafgjort()
        {
            uafgjort++;
        }

        public string getJSONData() {
            string json = "{\"name\":\"" + navn
                + "\",\"liv\":" + Convert.ToString(liv)
                + ",\"sejre\":" + Convert.ToString(sejre)
                + ",\"tab\":" + Convert.ToString(tab)
                + ",\"uafgjort\":" + Convert.ToString(tab) + ",\"vaaben\":[";
            for (int i = 0; i < vaaben.Count; i++)
            {
                json += vaaben[i];
                if (i < vaaben.Count-1) json += ",";
            }
            json += "],\"skjold\":[";
            for (int i = 0; i < skjold.Count; i++)
            {
                json += skjold[i];
                if (i < skjold.Count - 1) json += ",";
            }
            json += "]}";
            
            return json;
        }



        public string getUniqueFileUrl()
        {
            return ("r_" + id + "_" + xmlFileName);
        }
        public string getFileName()
        {
            return xmlFileName;
        }

        public int getId()
        {
            return id;
        }

        public void setId(int latestId)
        {
            id = latestId;
        }
    }
}