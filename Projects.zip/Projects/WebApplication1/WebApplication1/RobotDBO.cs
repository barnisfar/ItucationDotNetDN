﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Collections;

namespace WebApplication1
{
    public class RobotDBO
    {
        SqlConnection cnn;
        int latestId = 0;

        public RobotDBO() {
            //var conString = ConfigurationManager.ConnectionStrings["LocalSqlServer"];
            //string strConnString = conString.ConnectionString;
            cnn = new SqlConnection("Data Source=WIN-DBHSPC6ODT5\\MYSQL;Initial Catalog=RobotGame;Integrated Security=True;MultipleActiveResultSets=True");
            
            
        }

        public Robot getRobot(int id) {
            cnn.Open();
            string sql1 = "select * from Robot where robot_id = " + id;
            string sql2 = "select * from Round where robot_id = " + id; 
            SqlDataReader dbReader1;
            SqlDataReader dbReader2;

            SqlCommand myCommand = new SqlCommand(sql1, cnn);
            dbReader1 = myCommand.ExecuteReader();
            
            SqlCommand myCommand2 = new SqlCommand(sql2, cnn);
            dbReader2 = myCommand2.ExecuteReader();

            Robot robot = new Robot();
            ArrayList weapons = new ArrayList();
            ArrayList shields = new ArrayList(); 

            if (dbReader1.Read()) {
                while (dbReader2.Read()) {
                    weapons.Add(dbReader2["round_weapon"]);
                    shields.Add(dbReader2["round_shield"]);
                }
                robot = new Robot(
                    Convert.ToInt32(dbReader1["robot_id"]),
                    Convert.ToString(dbReader1["robot_name"]),
                    Convert.ToInt32(dbReader1["robot_lives"]), 
                    Convert.ToInt32(dbReader1["robot_losses"]), 
                    Convert.ToInt32(dbReader1["robot_wins"]),
                    Convert.ToInt32(dbReader1["robot_evens"]),
                    Convert.ToString(dbReader1["robot_filename"]),
                    shields, 
                    weapons
                    );
            }
            cnn.Close();
            return robot;
        }

        public int saveRobot(Robot robot) {
            cnn.Open();
            string sql1 = "select * from Robot where robot_id = " + robot.getId();
            string sql2 = "delete from Round where robot_id = " + robot.getId();
            SqlDataReader dbReader1;
            
            SqlCommand myCommand = new SqlCommand(sql1, cnn);
            dbReader1 = myCommand.ExecuteReader();

            SqlCommand myCommand3;

            if (dbReader1.Read()) {
                string sql3 = "update Robot set robot_name = '" + robot.getNavn() + "', robot_lives = " + robot.getLiv() + ", robot_losses = " + robot.getTab() + ", robot_wins = " + robot.getSejre() + ", robot_evens = " + robot.getUafgjort() + ", robot_filename = '" + robot.getFileName() + "' where robot_id = " + robot.getId();
                myCommand3 = new SqlCommand(sql3, cnn);
                myCommand3.ExecuteNonQuery();
            } 
            else {
                string sql3 = "insert into Robot (robot_name,robot_lives,robot_losses,robot_wins,robot_evens,robot_filename)  output inserted.robot_id values ('" + robot.getNavn() + "', " + robot.getLiv() + ", " + robot.getTab() + ", " + robot.getSejre() + ", " + robot.getUafgjort() + ", '" + robot.getFileName() + "');";
                myCommand3 = new SqlCommand(sql3, cnn);
                latestId = Convert.ToInt32(myCommand3.ExecuteScalar());
                robot.setId(latestId);
            }

            SqlCommand myCommand2 = new SqlCommand(sql2, cnn);
            myCommand2.ExecuteNonQuery();

            for (int i = 0; i < robot.getVaaben().Count; i++) {
                string sql4 = "insert into Round (round_weapon, round_shield, robot_id) values (" + robot.getVaaben(i) + ", " + robot.getSkjold(i) + ", " + robot.getId() + ")";
                SqlCommand myCommand4 = new SqlCommand(sql4, cnn);
                myCommand4.ExecuteNonQuery();
            }

            cnn.Close();
            return robot.getId();
        }

        public ArrayList getAllRobots()
        {
            cnn.Open();
            string sql1 = "select * from Robot";
            
            SqlDataReader dbReader1;
            
            SqlCommand myCommand = new SqlCommand(sql1, cnn);
            dbReader1 = myCommand.ExecuteReader();
            
            ArrayList robots = new ArrayList();
            
            while (dbReader1.Read()) {
                SqlDataReader dbReader2;
                string sql2 = "select * from Round where robot_id = " + dbReader1["robot_id"];
                SqlCommand myCommand2 = new SqlCommand(sql2, cnn);
                dbReader2 = myCommand2.ExecuteReader();

                Robot robot = new Robot();
                ArrayList weapons = new ArrayList();
                ArrayList shields = new ArrayList(); 

                while (dbReader2.Read()) {
                    weapons.Add(dbReader2["round_weapon"]);
                    shields.Add(dbReader2["round_shield"]);
                }

                robots.Add(new Robot(
                    Convert.ToInt32(dbReader1["robot_id"]),
                    Convert.ToString(dbReader1["robot_name"]),
                    Convert.ToInt32(dbReader1["robot_lives"]), 
                    Convert.ToInt32(dbReader1["robot_losses"]), 
                    Convert.ToInt32(dbReader1["robot_wins"]),
                    Convert.ToInt32(dbReader1["robot_evens"]),
                    Convert.ToString(dbReader1["robot_filename"]), 
                    shields, 
                    weapons));
            }
            cnn.Close();
            return robots;
        }

        public int getLatestId() { return latestId; }
    }
}