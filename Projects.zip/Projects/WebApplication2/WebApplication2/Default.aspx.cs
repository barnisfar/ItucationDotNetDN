﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace WebApplication2
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //var conString = ConfigurationManager.ConnectionStrings["LocalSqlServer"];
            //string strConnString = conString.ConnectionString;
            SqlDataReader myReader = null;
            string sqlCreateCore = "";
            SqlConnection cnn = new SqlConnection("Data Source=WIN-DBHSPC6ODT5\\MYSQL;Initial Catalog=HelloWorld;Integrated Security=True");
            cnn.Open();
            sqlCreateCore += "select * from myTable";
            SqlCommand myCommand = new SqlCommand(sqlCreateCore, cnn);
            myReader = myCommand.ExecuteReader();
            while (myReader.Read())
                MyTable.InnerText = Convert.ToString(myReader["nyText"]);

            myReader.Close();
        }
    }
}
