﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;

namespace Chat
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //Chat c = new Chat(1);
            //chatArea.InnerHtml = c.getName();
            //chatArea.InnerHtml += ((ChatMessage)c.getChatMessages(10)[0]).getValue("text");

            
        }
    }
}
