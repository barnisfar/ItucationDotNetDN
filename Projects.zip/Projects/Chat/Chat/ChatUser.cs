﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Chat
{
    public class ChatUser : SqlModel
    {
        public ChatUser(int id)
        {
            newSqlModel("ChatUser");
            load(id);
        }
    }
}