﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Collections;
using System.Collections.Specialized;

namespace Chat
{
    
    public class ChatMessage : SqlModel
    {
        private string text;
        private int chatId, userId;
        private string date;

        public int UserId { get { return userId; } set { userId = UserId; } }
        public int ChatId { get { return chatId; } set { chatId = ChatId; } }
        public string Text { get { return getValue("text"); } set { text = Text; } }
        public string Date { get { return getValue("date"); } set {  } }

        public ChatMessage()
        {
            newSqlModel("ChatMessage");
        }

        public ChatMessage(int id)
        {
            newSqlModel("ChatMessage");
            load(id);
            text = this.getValue("text");
        }

        public ChatMessage(int _chatId, int _userId, string _text)
        {
            newSqlModel("ChatMessage");
            text = _text;
            chatId = _chatId;
            userId = _userId;
            values.Add("text", text);
            values.Add("Chat_id", chatId);
            values.Add("ChatUser_id", userId);
            save(values);
        }

    }
}