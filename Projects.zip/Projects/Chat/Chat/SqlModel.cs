﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Collections;
using System.Data.SqlClient;
using System.Collections.Specialized;
using System.Web.Script.Serialization;

namespace Chat
{
    public class SqlModel
    {
        protected string table;
        protected SqlConnection cnn;
        protected int id = -1;
        protected string name;
        protected OrderedDictionary values;
        protected JavaScriptSerializer oSerializer;

        
        public int Id { get { return id; } set { id = Id; } }
        public string Name { get { return name; } set { name = Name; } }
        public string Values { get { return oSerializer.Serialize(values); } set { } }
        //public OrderedDictionary Values { get { return values; } set { } }
        

        public void newSqlModel(string _table) {
            oSerializer = new JavaScriptSerializer();
            values = new OrderedDictionary();
            table = _table;
            cnn = new SqlConnection("Data Source=WIN-DBHSPC6ODT5\\MYSQL;Initial Catalog=Chat;Integrated Security=True;MultipleActiveResultSets=True");
        }

        public int save() {
            OrderedDictionary propsVals = new OrderedDictionary();
            propsVals.Add("id", id);
            propsVals.Add("name", name);
            return save(propsVals);
        }

        public int save(OrderedDictionary propsValues)
        {
            object[] keys = new object[propsValues.Keys.Count];
            propsValues.Keys.CopyTo(keys, 0);

            cnn.Open();
            string sql1 = "select * from "+table+" where "+table+"_id = " + id;
            SqlDataReader dbReader1;

            SqlCommand myCommand = new SqlCommand(sql1, cnn);
            dbReader1 = myCommand.ExecuteReader();

            SqlCommand myCommand3;

            if (dbReader1.Read())
            {
                string sql3 = "update "+table+" set ";
                for (int i = 0; i < propsValues.Count; i++)
                {
                    sql3 += table + "_" + keys[i] + " = '" + propsValues[i] + "'";
                    if (i < propsValues.Count - 1) sql3 += ",";
                }
                myCommand3 = new SqlCommand(sql3, cnn);
                myCommand3.ExecuteNonQuery();
            }
            else
            {
                string sql3 = "insert into " + table + " (";

                for (int i = 0; i < propsValues.Count; i++)
                {
                    sql3 += table + "_" + keys[i];
                    if (i < propsValues.Count - 1) sql3 += ",";
                }

                sql3 += ") output inserted." + table + "_id values (";

                for (int i = 0; i < propsValues.Count; i++)
                {
                    sql3 += "'" + propsValues[i] + "'";
                    if (i < propsValues.Count - 1) sql3 += ",";
                }

                sql3 += ");";

                myCommand3 = new SqlCommand(sql3, cnn);
                int latestId = Convert.ToInt32(myCommand3.ExecuteScalar());
                this.id = latestId;
            }

            cnn.Close();
            return this.getId();
        }

        public SqlModel load(int id) {
            cnn.Open();

            string sql1 = "select * from " + table + " where " + table + "_id = " + id;
            SqlDataReader dbReader1;

            SqlCommand myCommand = new SqlCommand(sql1, cnn);
            dbReader1 = myCommand.ExecuteReader();
            
            if (dbReader1.Read()) {
                name = Convert.ToString(dbReader1[table + "_name"]);
                id = Convert.ToInt32(dbReader1[table + "_id"]);
                setValuesFromSql(dbReader1);
            }

            cnn.Close();
            return this;
        }

        public ArrayList loadCollection(string whereSql, int limit)
        {

            ArrayList models = new ArrayList();

            cnn.Open();

            string limitSql = "";

            if (limit > 0) limitSql = "top " + limit;

            string sql1 = "select " + limitSql + " * from " + table + " where " + whereSql + " order by " + table + "_id ASC";
            SqlDataReader dbReader1;

            SqlCommand myCommand = new SqlCommand(sql1, cnn);
            dbReader1 = myCommand.ExecuteReader();

            while (dbReader1.Read())
            {
                setName(Convert.ToString(dbReader1[table + "_name"]));
                setId(Convert.ToInt32(dbReader1[table + "_id"]));
                setValuesFromSql(dbReader1);
                models.Add(this.DeepCopy());
            }

            cnn.Close();

            return models;
        }

        private void setId(int _id)
        {
            id = _id;
        }

        public int getId() { return id;}

        private void setName(string _name)
        {
            name = _name;
        }

        public string getName() { return name; }

        private void setValuesFromSql(SqlDataReader _values)
        {
            values.Clear();
            for (int key = 0; key < _values.FieldCount; key++)
            {
                string sKey = _values.GetName(key);
                values.Add(sKey, _values[key]);
            }
        }

        private void setValues(OrderedDictionary _values)
        {
            OrderedDictionary newValues = new OrderedDictionary();
            object[] keys = new object[_values.Keys.Count];
            _values.Keys.CopyTo(keys, 0);

            for (int key = 0; key < _values.Count; key++)
            {
                newValues.Add(keys[key], _values[key]);
            }
            values = newValues;
        }

        public string getValue(string key) { return Convert.ToString(values[table+"_"+key]); }

        public SqlModel DeepCopy()
        {
            SqlModel temp = (SqlModel)this.MemberwiseClone();
            //Creating a new memory for the object and setting same values from the original
            temp.table = this.table;
            temp.id = this.id;
            temp.name = this.name;
            temp.setValues(this.values);
            return temp;
        }


    }

}