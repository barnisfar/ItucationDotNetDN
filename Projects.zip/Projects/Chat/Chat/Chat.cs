﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Collections;

namespace Chat
{
    public class Chat : SqlModel
    {
        private ChatRoom chatRoom;
        private ArrayList chatMessages;
        public string ChatMessages { get { return oSerializer.Serialize(chatMessages); } set { } }
        

        public Chat(string _name, ChatRoom _chatRoom) {
            newSqlModel("Chat");
        }

        public Chat() {}

        public Chat(int _id) { loadChat(_id, 0); }

        public void loadChat(int _id, int _latestChatMessageId)
        {
            id = _id;
            newSqlModel("Chat");
            load(_id);
            chatMessages = getChatMessages(10, _latestChatMessageId);
        }

        public ArrayList getChatMessages(int limit, int _latestChatMessageId)
        {
            chatMessages = new ChatMessage().loadCollection("ChatMessage_Chat_id = " + id + " and ChatMessage_id > " + _latestChatMessageId, limit);
            return chatMessages;
        }

    }
}