﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Chat
{
    public class ChatRoom : SqlModel
    {
        public ChatRoom(int id)
        {
            newSqlModel("ChatRoom");
            load(id);
        }
    }
}