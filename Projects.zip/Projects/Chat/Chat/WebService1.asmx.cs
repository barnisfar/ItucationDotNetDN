﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Collections.Specialized;

namespace Chat
{
    /// <summary>
    /// Summary description for WebService1
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    [System.Web.Script.Services.ScriptService]
    public class WebService1 : System.Web.Services.WebService
    {
        
        [WebMethod]
        public Chat LoadChat(string chatId, int latestChatMessageId)
        {
            Chat c = new Chat();
            c.loadChat(Convert.ToInt32(chatId), latestChatMessageId);
            
            return c;
        }

        [WebMethod]
        public ChatMessage SaveChatMessage(string chatId, string userId, string text)
        {
            ChatMessage cMessage = new ChatMessage(Convert.ToInt32(chatId), Convert.ToInt32(userId), text);
            //cMessage.save();
            return cMessage;
        }

        [WebMethod]
        public ChatMessage LoadChatMessage()
        {
            return new ChatMessage(getPostVarInt("Id"));
        }

        private string getPostVar(string key)
        {
            HttpContext c = HttpContext.Current;
            string val = "";
            if (c.Request[key] != null)
                val = c.Request[key];
            return val;
        }

        private int getPostVarInt(string key)
        {
            return Convert.ToInt32(getPostVar(key));
        }
    }
}
