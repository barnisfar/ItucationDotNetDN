﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class MatchsticksConsoleUI : MatchsticksUI
    {
        bool guiMode = false;

        public MatchsticksConsoleUI(Matchsticks _m) {
            matchsticks = _m;
        }

        public override void updateStatusTxt(string status)
        {
            Console.WriteLine(status);
        }

        public override void listenForInput()
        {
            int inputNumber;

            do
            {
                inputNumber = Convert.ToInt32(Console.ReadLine());
            }
            while (inputNumber > 3 || inputNumber < 1);

            matchsticks.takeSticks(inputNumber);
        }

        public override void prepareUsers()
        {
            int _nPlayers = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Spiller 1, hvad er dit navn?");
            string p1 = Console.ReadLine();
            string p2 = "Computer";
            if (_nPlayers != 1)
            {
                Console.WriteLine("Spiller 2, hvad er dit navn?");
                p2 = Console.ReadLine();
            }
            matchsticks.initGame(p1, p2);

        }

        public override bool isGUIMode() { return guiMode; }

    }
}
