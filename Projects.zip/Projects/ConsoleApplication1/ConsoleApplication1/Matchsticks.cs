﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ConsoleApplication1
{
    public class Matchsticks
    {
        private int sticksLeft;
        private string[] players;
        private int lastTurn;
        
        private int currentPlayer = 0;
        private MatchsticksWinUI sticksUI;

        public Matchsticks() {
            sticksUI = new MatchsticksWinUI(this);

            string o = "Velkommen til matchsticks. Hvor mange spillere? 1 eller 2";
            sticksUI.updateStatusTxt(o);

            sticksUI.prepareUsers();
        }

        public void initGame(string p1, string p2) {
            sticksLeft = 15;
            lastTurn = 0;
            players = new string[2];
            players[0] = p1;
            players[1] = p2;
            runGame();
        }

        public void runGame() {
            
                if (players[currentPlayer] != "Computer")
                { 
                    promptPlayerTurn();
                }
                else aiTurn();

                if (sticksLeft <= 0)
                {
                    loose(currentPlayer);
                }
                else
                {
                    if (++currentPlayer >= players.Length) currentPlayer = 0;
                }
                System.Threading.Thread.Sleep(200);
        }

        private void loose(int _currentPlayer) {
            string output = players[_currentPlayer] + " har tabt. Nyt spil? [j/n]";
            sticksUI.updateStatusTxt(output);
            //if (Console.ReadLine().StartsWith("j")) initGame(players[0], players[1]);
        }
        
        private void promptPlayerTurn() {

            string output = sticksLeft + " tændstikker tilbage. " + players[currentPlayer] + ", tag 1, 2 eller 3 tændstikker...";
            sticksUI.updateStatusTxt(output);
            sticksUI.listenForInput();

        }

        public void takeSticks(int inputNumber) {
            sticksLeft -= inputNumber;
            lastTurn = inputNumber;
            runGame();
        }

        private void aiTurn() {

            int nextTurn = sticksLeft - 13;
            
            if (nextTurn <= 0) {
                nextTurn = 4-lastTurn;
            }

            string o = "Computeren tager " + nextTurn + " tændstik(ker)...";
            sticksUI.updateStatusTxt(o);
                
            sticksLeft -= nextTurn;

            System.Threading.Thread.Sleep(2000);
 
        }

    }
}
