﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace ConsoleApplication1
{
    internal static class NativeMethods
    {
        [DllImport("kernel32.dll")]
        internal static extern Boolean AllocConsole();
    }

    static class Program
    {

        static void Main(string[] args) {
            if (args.Length == 0) {
                // run as windows app
                Application.EnableVisualStyles();
                Matchsticks m1 = new Matchsticks();
            } else {
                // run as console app
                NativeMethods.AllocConsole();
                Console.WriteLine("Hello World");
                Console.ReadLine();
            }
        }
            //f5 kør
            //shift f5 stop
            //ctrl shift f5 kør igen
            

            //if () {} else {} for, while, do {} while ();

            //operatorer

            //Class1 class1 = new Class1();
            //Console.Write(class1.getString());
            //Console.Read();

    }
}
