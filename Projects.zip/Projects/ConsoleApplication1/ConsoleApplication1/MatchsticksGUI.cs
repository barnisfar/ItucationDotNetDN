﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    public class MatchsticksGUI : MatchsticksWinUI
    {
        bool guiMode = true;

        public MatchsticksGUI(Matchsticks _m) {
            matchsticks = _m;
        }
        
        public void updateStatusTxt(string status)
        {
            this.label4.Text = status;
            this.Update();
        }

        public bool isGUIMode() { return guiMode; }

        public void listenForInput()
        {
            //
        }



        public void prepareUsers()
        {
            matchsticks.initGame(this.textBox1.Text, this.textBox2.Text);
        }
    }
}
