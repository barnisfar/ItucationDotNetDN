﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ConsoleApplication1
{

    abstract class MatchsticksUI
    {
        protected Matchsticks matchsticks;

        

        public abstract void updateStatusTxt(string status);

        public abstract void listenForInput();

        public abstract bool isGUIMode();

        public abstract void prepareUsers();
    }
}
